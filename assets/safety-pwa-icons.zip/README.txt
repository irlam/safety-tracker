Safety Tours — PWA Icons
--------------------------------
Place all PNGs and favicon.ico in: /assets/icons (create folder if missing)
Place manifest.json in your web root and link it in <head>:

<link rel="manifest" href="/manifest.json">
<link rel="icon" href="/assets/icons/favicon.ico">
<link rel="apple-touch-icon" href="/assets/icons/apple-touch-icon.png">
<meta name="theme-color" content="#0ea5e9">

Update paths if your icons folder differs.
